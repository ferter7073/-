package com.tntalert.mixin;

import com.tntalert.TntAlertMod;
import net.minecraft.client.sound.SoundInstance;
import net.minecraft.client.sound.SoundManager;
import net.minecraft.sound.SoundEvents;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(SoundManager.class)
public class SoundManagerMixin {

    /**
     * Перехватываем каждый воспроизводимый звук.
     * Если это звук взрыва — уведомляем мод.
     */
    @Inject(method = "play(Lnet/minecraft/client/sound/SoundInstance;)V", at = @At("HEAD"))
    private void onPlay(SoundInstance sound, CallbackInfo ci) {
        if (sound == null || sound.getId() == null) return;

        String soundId = sound.getId().toString();

        // entity.generic.explode — стандартный звук взрыва (TNT, крипер и т.д.)
        if (soundId.equals("minecraft:entity.generic.explode")) {
            TntAlertMod.onExplosionSoundHeard();
        }
    }
}
