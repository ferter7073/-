package com.tntalert;

import net.fabricmc.api.ClientModInitializer;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.atomic.AtomicLong;

public class TntAlertMod implements ClientModInitializer {

    public static final Logger LOGGER = LoggerFactory.getLogger("tntalert");

    // ======= НАСТРОЙКИ =======
    // Вставь сюда новый токен после отзыва старого!
    private static final String BOT_TOKEN = "ВАШ_НОВЫЙ_ТОКЕН_БОТА";
    private static final String CHAT_ID   = "1237657062";
    private static final long   COOLDOWN_MS = 10_000; // 10 секунд между уведомлениями
    // =========================

    private static final HttpClient HTTP = HttpClient.newHttpClient();
    private static final ScheduledExecutorService EXECUTOR =
            Executors.newSingleThreadScheduledExecutor(r -> {
                Thread t = new Thread(r, "tnt-alert-sender");
                t.setDaemon(true);
                return t;
            });

    /** Флаг: сейчас идёт кулдаун (не слать новые уведомления) */
    private static final AtomicBoolean onCooldown = new AtomicBoolean(false);

    /** Время последнего отправленного уведомления */
    private static final AtomicLong lastSent = new AtomicLong(0);

    @Override
    public void onInitializeClient() {
        LOGGER.info("[TNT Alert] Мод загружен! Chat ID: {}", CHAT_ID);
    }

    /**
     * Вызывается из миксина когда слышен звук взрыва.
     */
    public static void onExplosionSoundHeard() {
        long now = System.currentTimeMillis();

        // Проверяем кулдаун
        if (onCooldown.get()) return;
        if (now - lastSent.get() < COOLDOWN_MS) return;

        // Ставим кулдаун и запоминаем время
        onCooldown.set(true);
        lastSent.set(now);

        LOGGER.info("[TNT Alert] Слышен взрыв! Отправляю уведомление в Telegram...");

        // Отправляем асинхронно, чтобы не лагал клиент
        EXECUTOR.submit(() -> {
            sendTelegram("💥 Рядом с тобой взрыв динамита!");
            // Снимаем кулдаун через 10 секунд
            EXECUTOR.schedule(() -> onCooldown.set(false), COOLDOWN_MS, TimeUnit.MILLISECONDS);
        });
    }

    private static void sendTelegram(String message) {
        try {
            String encodedMsg = URLEncoder.encode(message, StandardCharsets.UTF_8);
            String url = String.format(
                "https://api.telegram.org/bot%s/sendMessage?chat_id=%s&text=%s",
                BOT_TOKEN, CHAT_ID, encodedMsg
            );

            HttpRequest req = HttpRequest.newBuilder()
                .uri(URI.create(url))
                .GET()
                .build();

            HttpResponse<String> resp = HTTP.send(req, HttpResponse.BodyHandlers.ofString());
            LOGGER.info("[TNT Alert] Telegram ответил: {}", resp.statusCode());

        } catch (Exception e) {
            LOGGER.error("[TNT Alert] Ошибка отправки в Telegram: {}", e.getMessage());
        }
    }
}
